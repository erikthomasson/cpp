I mapparna finns filer att anv�nda som indata till de olika implementationsvalen
F�r implementationsval 1 f�r du sj�lv ange start samt slutnod som skrivet i uppgiftsbeskrivningen