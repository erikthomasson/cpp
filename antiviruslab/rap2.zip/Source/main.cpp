/*
Erik Thomasson
*/
#include "Functions.hpp"

int main(int argc , char *path[]){
    checkthevirusdatabase();
    filtraversering((char*)path[1]);

    return 0;
}